<?php include("Login/header.php");?>

        <label for="uname"><b>Username</b></label>
        <input type="text" name="uname" placeholder="Ex: ut23"  required>

        <label for="psw"><b>Password</b></label>
        <input type="password" name="psw" placeholder="Enter Password"  required>

        <button class="Login_Form_Button" type="submit">Login</button>


<?php include("Login/footer.php");