
<?php

$hostname = "sql1.njit.edu" ;
$username = "ti36" ;
$project = "ti36" ;
$password = "fQ8f50AMO" ;


?>
