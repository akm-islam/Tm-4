<?php
	session_start();
	session_destroy();
?>
<?php include ("header.php");?>

<span class="login100-form-title p-b-34 p-t-27">
    Thank You for using our app.
</span>

<br><br>

<div class="container-login100-form-btn">
    <a class="login100-form-btn" href="login_form.php" role="button">Login again</a><br><br>
    <!--    <a class=\"login100-form-btn\" href=\"Dash/dashboard.html\" role=\"button\">Back Dashboard</a><br>-->
</div>

<?php include ("footer.php");?>
