
<?php

$hostname = "sql1.njit.edu" ;
$DBusername = "ti36" ;
$project = "ti36" ;
$DBpassword = "fQ8f50AMO" ;


?>
